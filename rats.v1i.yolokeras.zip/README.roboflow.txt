
rats - v1 2021-07-06 1:37am
==============================

This dataset was exported via roboflow.ai on July 6, 2021 at 5:39 AM GMT

It includes 75 images.
Rats are annotated in YOLO v3 (Keras) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random shear of between -15° to +15° horizontally and -15° to +15° vertically
* Salt and pepper noise was applied to 5 percent of pixels


